package com.codepresso.yctechaws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YctechAwsApplicationTests {

	@Test
	void contextLoads() {
	}

}
