package com.codepresso.yctechaws.controller;

import com.codepresso.yctechaws.repository.MyFileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.InetAddress;
import java.net.UnknownHostException;


@RestController
public class MyFileController {

    @Autowired
    private MyFileRepository myFileRepository;

    @GetMapping("/")
    public String get() {
        String hostname = "";
        try {
            hostname = InetAddress.getLocalHost().getHostAddress();
        } catch (UnknownHostException e) {
            throw new RuntimeException(e);
        }
        return hostname + ": "+ myFileRepository.findAll();
    }
}
