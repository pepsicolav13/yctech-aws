package com.codepresso.yctechaws.model;

import jakarta.persistence.*;

@Entity
@Table(name = "MyFiles")
public class MyFile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "name")
    private String name;

    @Column(name = "size")
    private int size;

    @Column(name = "url")
    private String url;

    public MyFile() {
        this("Untitled", 0, "");
    }

    public MyFile(String name, int size, String url) {
        this.name = name;
        this.size = size;
        this.url = url;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public String toString() {
        return "User [id=" + id + ", name=" + name + ", size=" + size + ", url=" + url + "]";
    }
}