package com.codepresso.yctechaws.repository;


import com.codepresso.yctechaws.model.MyFile;
import org.springframework.data.repository.ListCrudRepository;

import java.util.List;

public interface MyFileRepository extends ListCrudRepository<MyFile, Long> {

    List<MyFile> findByName(String name);
    MyFile findById(long id);
}
